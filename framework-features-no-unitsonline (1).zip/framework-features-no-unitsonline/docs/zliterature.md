# Literature References

```{eval-rst}
.. bibliography:: references.bib
    :all:
    :style: unsrt
```
