---
title: Privacy
subtitle: 
comments: false
---

## Privacy statement

This website is deployed using [GitLab pages](https://about.gitlab.com/stages-devops-lifecycle/pages/).

Therefore, please refer to [GitLab's privacy policy](https://about.gitlab.com/privacy/).
