# remix.framework.cli package

```{toctree}
:maxdepth: 2
```

## remix.framework.cli.main module

```{eval-rst}
.. automodule:: remix.framework.cli.main
   :members:
   :undoc-members:
   :show-inheritance:
```

## remix.framework.cli.run module

```{eval-rst}
.. automodule:: remix.framework.cli.run
   :members:
   :undoc-members:
   :show-inheritance:
```

## remix.framework.cli.test module

```{eval-rst}
.. automodule:: remix.framework.cli.test
   :members:
   :undoc-members:
   :show-inheritance:
```
