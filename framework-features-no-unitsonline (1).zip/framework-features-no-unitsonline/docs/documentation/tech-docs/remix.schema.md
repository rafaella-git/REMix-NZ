# remix.framework.schema package

```{toctree}
:maxdepth: 2
```

## remix.framework.schema.manager module

```{eval-rst}
.. automodule:: remix.framework.schema.manager
   :members:
   :undoc-members:
   :show-inheritance:
```

## remix.framework.schema.parser module

```{eval-rst}
.. automodule:: remix.framework.schema.parser
   :members:
   :undoc-members:
   :show-inheritance:
```

## remix.framework.schema.templates module

```{eval-rst}
.. automodule:: remix.framework.schema.templates
   :members:
   :undoc-members:
   :show-inheritance:
```
