(remix_model_label)=

# remix.framework.model package (GAMS)

In the sections linked below you can find the documentation of the GAMS model
code.
The list the equations applied is listed together with the available input
data tables.

```{toctree}
:glob:
:maxdepth: 1

*
```