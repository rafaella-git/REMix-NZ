from remix.framework.schema.parser import main as parse


def program_build_schemas():
    """Build the schemas for the current version."""
    parse()