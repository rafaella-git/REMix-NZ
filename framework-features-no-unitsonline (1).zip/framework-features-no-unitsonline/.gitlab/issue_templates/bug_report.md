## Short description

(Please briefly describe and give context)

## Steps to reproduce

(What steps did you take to encounter the bug? If possible, please provide a
minimal example, to reproduce the bug.)

## What is the actual behavior?

(What actually happens)

## What is the expected behavior?

(What you expect to happen instead)

## Software versions

- REMix: ()
- GAMS: ()
- Python: ()
- OS: ()

/label ~bug
