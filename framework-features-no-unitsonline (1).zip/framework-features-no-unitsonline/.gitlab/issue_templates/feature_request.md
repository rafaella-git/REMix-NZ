## Short description

(Please briefly describe your feature suggestion)

## Example application

(In what context or real-world application can the feature be useful?)

## Mathematical formulation

(If possible, can you provide a mathematical description of the suggested
feature.)

/label ~feature request
